%--------------------------------------------例文case1
%0=grad(A(p)p)+f
clear
clc
tic
%-------------------------------------------------------------------定义变量
miu=1e-03;
ka=1e-13;
Cf=0;
N=40;%-------------------------------------------------例文里N=400
L=400;
Delta=L/N;
Horizon=3*Delta;
nxH=3;
nyH=3;
x_len=nxH*Horizon;
y_len=nyH*Horizon;
xl_int=fix(x_len/Delta);
yl_int=fix(y_len/Delta);
n_elem = (N+yl_int*2+1)*(N+xl_int*2+1);
center=(1+n_elem)/2;
B=zeros(n_elem);
p_0=zeros(n_elem,1);
u_p=zeros(n_elem,1);


%--------------------------------------------------------------------排[0,L]^2
V=1;
elements=zeros(n_elem,2);
for i=0:(N+yl_int*2)
    for j=0:(N+xl_int*2)
        elements(V,2)=L*(i/N-yl_int/N);
        elements(V,1)=L*(j/N-xl_int/N);
        V=V+1;
    end
end
%-------------------------------------------------------------------区分内外点
for i=1:n_elem
    xi=elements(i,1);
    yi=elements(i,2);
    if (xi<=0||xi>=L||yi<=0||yi>=L)%---------------------------边界
        scrnum(i,1)=1;
    end
    if (xi==0&&yi==0)||(xi==0&&yi==L)||(xi==L&&yi==0)||(xi==L&&yi==L)%--------------边界四个角
        scrnum(i,1)=2;
    end
end
%-------------------------------------------------------------------初始值赋值
p0=0;
%扩散系数
a=@(x,y) 1;
b=0;
c=0;
d=@(x,y) 1;


 for i=1:n_elem
    
    xi=elements(i,1);
    yi=elements(i,2);
    

    %求M
    A_x=[a(xi,yi),0;0,d(xi,yi)];  
    [V_x,D_x]=eig(A_x);
    M_x_inverse=V_x*sqrt(inv(D_x))*V_x';

    if scrnum(i,1)==0

        ennum=0;
        num=0;
        enennum=0;
        kernel=zeros(1300,1);
        Aeq=zeros(5,1300);
        NAeq=zeros(1300,1);
        elements_1=zeros(1300,2);


      for j=1:n_elem
          

           xj=elements(j,1);
           yj=elements(j,2);

           A_y=[a(xj,yj),0;0,d(xj,yj)];
           [V_y,D_y]=eig(A_y);
           M_y_inverse=V_y*sqrt(inv(D_y))*V_y';
           
           
           %截断条件B
        
            if((i~=j)&&((xj-xi).^2+(yj-yi).^2<=Horizon.^2))
   

                enennum=enennum+1;

                m1=(ka/miu)*(1/(pi*Horizon.^2)).*((xj-xi).^2*M_x_inverse(1,1).^2+(yj-yi).^2*M_x_inverse(2,2).^2).^(-3/2).*det(M_x_inverse);
                m2=(ka/miu)*(1/(pi*Horizon.^2)).*((xj-xi).^2*M_y_inverse(1,1).^2+(yj-yi).^2*M_y_inverse(2,2).^2).^(-3/2).*det(M_y_inverse);

                kernel(enennum,1)=m1+m2;

                elements_1(enennum,1)=xj;
                elements_1(enennum,2)=yj;

                               
                Aeq(1,enennum)=(xj-xi).*kernel(enennum,1);
                Aeq(2,enennum)=(yj-yi).*kernel(enennum,1);
                Aeq(3,enennum)=(xj*yj-xi*yi).*kernel(enennum,1);
                Aeq(4,enennum)=(xj.^2-xi.^2).*kernel(enennum,1);
                Aeq(5,enennum)=(yj.^2-yi.^2).*kernel(enennum,1);
                   
                NAeq(enennum,1)=j;
                   
           end
      end

     
        beq=zeros(5,1);
        
        beq(1,1)=0;
        beq(2,1)=0;
        beq(3,1)=0;
        beq(4,1)=2*(ka/miu);
        beq(5,1)=2*(ka/miu);
     

        S=Aeq*Aeq';
        x=Aeq'*inv(S)*beq;

        for k=1:num+ennum+enennum
              A(i,NAeq(k,1))=x(k).*kernel(k,1);
        end

    end
 end

for i=1:n_elem
    if scrnum(i,1)==1||scrnum(i,1)==2
        A(i,i)=1;
    else
        A(i,i)=-sum(A(i,:));
    end
end%--------------------------------------------------------------------------------右端怎么给？
ne=1e-03/(Delta^2);
po=-1e-03/(Delta^2);
 for i=1:n_elem
    xi=elements(i,1);
    yi=elements(i,2);
    %-------------------------镜像边界
   if (scrnum(i,1)==1)
    if(xi>=L&&yi>=0&&yi<=L)%--------右%------------------------------------------------------修改
        f(i,1)=-miu/(4*pi*ka)*(ne*log((xi-2*L)^2+(yi-0)^2)+po*log((xi-L)^2+(yi-L)^2));
    end
    if (xi<=0&&yi>=0&&yi<=L)%--------左%------------------------------------------------------修改
        f(i,1)=-miu/(4*pi*ka)*(ne*log((xi+2*L-2*L)^2+(yi-0)^2)+po*log((xi+2*L-L)^2+(yi-L)^2));
    end
    if (yi>=L&&xi>=0&&xi<=L)%--------上%------------------------------------------------------修改
        f(i,1)=-miu/(4*pi*ka)*(ne*log((xi-0)^2+(yi-2*L)^2)+po*log((xi-L)^2+(yi-L)^2));
    end
    if (yi<=0&&xi>=0&&xi<=L)%--------下%------------------------------------------------------修改
        f(i,1)=-miu/(4*pi*ka)*(ne*log((xi-0)^2+(yi+2*L-2*L)^2)+po*log((xi-L)^2+(yi+2*L-L)^2));
    end
    if (yi<0&&xi>L)%--------右下%------------------------------------------------------修改
        f(i,1)=-miu/(4*pi*ka)*(ne*log((xi-2*L)^2+(yi+2*L-2*L)^2)+po*log((xi-L)^2+(yi+2*L-L)^2));
    end
    if (yi>L&&xi>L)%--------右上%------------------------------------------------------修改
        f(i,1)=-miu/(4*pi*ka)*(ne*log((xi-2*L)^2+(yi-2*L)^2)+po*log((xi-L)^2+(yi-L)^2));
    end
    if (xi<0&&yi<0)%--------左下%------------------------------------------------------修改
        f(i,1)=-miu/(4*pi*ka)*(ne*log((xi+2*L-2*L)^2+(yi+2*L-2*L)^2)+po*log((xi+2*L-L)^2+(yi+2*L-L)^2));
    end
    if (xi<0&&yi>L)%--------左上%------------------------------------------------------修改
        f(i,1)=-miu/(4*pi*ka)*(ne*log((xi+2*L-2*L)^2+(yi-2*L)^2)+po*log((xi+2*L-L)^2+(yi-L)^2));
    end
   end
 end
 
 for i=1:n_elem
    xi=elements(i,1);
    yi=elements(i,2);
    if xi==0&&yi==0
        f(i,1)=ne;
    end
    if xi==L&&yi==L
        f(i,1)=po;
    end
 end
p=A\f;%-------------------------迭代步长

%-------------------------------------------------------------计算误差
for i=1:n_elem
    xi=elements(i,1);
    yi=elements(i,2);
    if (scrnum(i,1)==0)&&i~=center
        u_p(i,1)=-miu/(4*pi*ka)*(ne*log((xi-0)^2+(yi-0)^2)+po*log((xi-L)^2+(yi-L)^2));
    end
    u_p(center,1)=po;
end
ERROR=p-u_p;
i=1;
for j=1:n_elem
    if scrnum(j,1)==0
        error(i,1)=ERROR(j,1);
        i=i+1;
    end
end
ee=max(abs(error));
%--------------------------------------------------------------------------pressure画图
i=1;
for j=1:n_elem
    if scrnum(j,1)==0
        n_elements(i,1)=elements(j,1);
        n_elements(i,2)=elements(j,2);
        n_P(i,1)=p(j,1);
        n_u_p(i,1)=u_p(j,1);
        i=i+1;
    end
end
X=reshape(n_elements(:,1),sqrt(size(n_elements,1)),sqrt(size(n_elements,1)));
Y=X';
P=reshape(n_P,sqrt(size(n_elements,1)),sqrt(size(n_elements,1)));
U_p=reshape(n_u_p,sqrt(size(n_elements,1)),sqrt(size(n_elements,1)));
%----------------------------------------------------------------------------误差：L_2

L2s=0;
L2ss=0;
for i=1:size(error)
    L2s=L2s+(error(i))^2;
    L2ss=L2ss+n_u_p(i)^2;
end
L2=(L2s/L2ss)^(1/2)

% save('X.txt','X','-ascii')
% save('Y.txt','Y','-ascii')
 % save('U_p_tr.txt','P','-ascii')
% save('U_p.txt','U_p','-ascii')


%
figure(1)
subplot(1,2,1)
surf(X,Y,P)
hold on
% contour(X,Y,P)
 title('解析解')
colorbar('eastoutside');
% caxis([m_inf m_sup]);
subplot(1,2,2)
surf(X,Y,U_p)
hold on
% contour(X,Y,U_p)
 title('真解')
colorbar('eastoutside');
camp=colormap(othercolor('BuDRd_12'));
% camp=camp(end:-1:1,:);
colormap(camp)

toc


