%--------------------------------------------例文case1
%0=grad(A(p)p)+f
clear
clc
%-------------------------------------------------------------------定义变量
miu=1e-03;
ka=1e-13;
Cf=0;
N=40;%-------------------------------------------------例文里N=400
L=400;
Delta=L/N;
Horizon=3.015*Delta;
nxH=2;
nyH=2;
x_len=nxH*Horizon;
y_len=nyH*Horizon;
xl_int=fix(x_len/Delta);
yl_int=fix(y_len/Delta);
n_elem = (N+yl_int*2+1)*(N+xl_int*2+1);
center=(1+n_elem)/2;
B=zeros(n_elem);
p_0=zeros(n_elem,1);
u_p=zeros(n_elem,1);

A_diff=zeros(2*n_elem,2*n_elem);
grad=zeros(2*n_elem,n_elem);
dive=zeros(n_elem,2*n_elem);

k=(n_elem+1)/2;

%--------------------------------------------------------------------排[0,L]^2
V=1;
elements=zeros(n_elem,2);
for i=0:(N+yl_int*2)
    for j=0:(N+xl_int*2)
        elements(V,2)=L*(i/N-yl_int/N);
        elements(V,1)=L*(j/N-xl_int/N);
        V=V+1;
    end
end
%-------------------------------------------------------------------区分内外点
for i=1:n_elem
    xi=elements(i,1);
    yi=elements(i,2);
    if (xi<=0||xi>=L||yi<=0||yi>=L)%---------------------------边界
        scrnum(i,1)=1;
    end
    if (xi==0&&yi==0)||(xi==0&&yi==L)||(xi==L&&yi==0)||(xi==L&&yi==L)%--------------边界四个角
        scrnum(i,1)=2;
    end
end

s2=zeros(2);
for i=k
    for j=1:n_elem

           xi=elements(i,1);
           yi=elements(i,2);
           xj=elements(j,1);
           yj=elements(j,2);

        if(i~=j&&((xj-xi).^2+(yj-yi).^2<=Horizon.^2))
%             omega=1/(1-e^(-9))*(e^(-((xj-xi).^2+(yj-yi).^2)/Delta^2)-e^(-9));
           omega=1;
           s1=[(xj-xi).^2,(xj-xi)*(yj-yi);(xj-xi)*(yj-yi),(yj-yi).^2]*Delta.^2*omega;
           s2=s1+s2;              
        end
    end
end

%-------------------------------------------------------------------初始值赋值
p0=0;
%---------------------------------------------------------组装矩阵
f=zeros(n_elem,1);
for i=1:n_elem
    for j=1:n_elem
        xi=elements(i,1);
        yi=elements(i,2);
        xj=elements(j,1);
        yj=elements(j,2);
        if i~=j
            a=1;
            b=0;
            c=0;
            d=1;

            if ((xj-xi).^2+(yj-yi).^2)<=(Horizon.^2)
               omega=1;
               s=inv(s2);

               %系数矩阵2N*2N(仅在分块对角线上)
               A_diff(2*i-1,2*i-1)=(ka/miu)*a;
               A_diff(2*i-1,2*i)=0;
               A_diff(2*i,2*i-1)=0;
               A_diff(2*i,2*i)=(ka/miu)*d;

               %梯度矩阵
               grad(2*i-1,j)=(s(1,1)*(xj-xi)+s(1,2)*(yj-yi))*omega*Delta.^2;
               grad(2*i,j)=(s(2,1)*(xj-xi)+s(2,2)*(yj-yi))*omega*Delta.^2;

               %散度矩阵
               dive(i,2*j-1)=(s(1,1)*(xj-xi)+s(1,2)*(yj-yi))*omega*Delta.^2;
               dive(i,2*j)=(s(2,1)*(xj-xi)+s(2,2)*(yj-yi))*omega*Delta.^2;

            end
        end
    end
end

 A2=dive*A_diff*grad;

 for i=1:n_elem
     A2(i,i)=0;
 end
  
 for i=1:n_elem
        
        if scrnum(i,1)==0
            A2(i,i)=-sum(A2(i,:));
        else
            A2(i,:)=0;
            A2(i,i)=1;
        end
 end

%--------------------------------------------------------------------------------右端怎么给？
ne=1e-03/(Delta^2);
po=-1e-03/(Delta^2);
 for i=1:n_elem
    xi=elements(i,1);
    yi=elements(i,2);
    %-------------------------镜像边界
   if (scrnum(i,1)==1)
    if(xi>=L&&yi>=0&&yi<=L)%--------右%------------------------------------------------------修改
        f(i,1)=-miu/(4*pi*ka)*(ne*log((xi-2*L)^2+(yi-0)^2)+po*log((xi-L)^2+(yi-L)^2));
    end
    if (xi<=0&&yi>=0&&yi<=L)%--------左%------------------------------------------------------修改
        f(i,1)=-miu/(4*pi*ka)*(ne*log((xi+2*L-2*L)^2+(yi-0)^2)+po*log((xi+2*L-L)^2+(yi-L)^2));
    end
    if (yi>=L&&xi>=0&&xi<=L)%--------上%------------------------------------------------------修改
        f(i,1)=-miu/(4*pi*ka)*(ne*log((xi-0)^2+(yi-2*L)^2)+po*log((xi-L)^2+(yi-L)^2));
    end
    if (yi<=0&&xi>=0&&xi<=L)%--------下%------------------------------------------------------修改
        f(i,1)=-miu/(4*pi*ka)*(ne*log((xi-0)^2+(yi+2*L-2*L)^2)+po*log((xi-L)^2+(yi+2*L-L)^2));
    end
    if (yi<0&&xi>L)%--------右下%------------------------------------------------------修改
        f(i,1)=-miu/(4*pi*ka)*(ne*log((xi-2*L)^2+(yi+2*L-2*L)^2)+po*log((xi-L)^2+(yi+2*L-L)^2));
    end
    if (yi>L&&xi>L)%--------右上%------------------------------------------------------修改
        f(i,1)=-miu/(4*pi*ka)*(ne*log((xi-2*L)^2+(yi-2*L)^2)+po*log((xi-L)^2+(yi-L)^2));
    end
    if (xi<0&&yi<0)%--------左下%------------------------------------------------------修改
        f(i,1)=-miu/(4*pi*ka)*(ne*log((xi+2*L-2*L)^2+(yi+2*L-2*L)^2)+po*log((xi+2*L-L)^2+(yi+2*L-L)^2));
    end
    if (xi<0&&yi>L)%--------左上%------------------------------------------------------修改
        f(i,1)=-miu/(4*pi*ka)*(ne*log((xi+2*L-2*L)^2+(yi-2*L)^2)+po*log((xi+2*L-L)^2+(yi-L)^2));
    end
   end
 end
 
 for i=1:n_elem
    xi=elements(i,1);
    yi=elements(i,2);
    if xi==0&&yi==0
        f(i,1)=ne;
    end
    if xi==L&&yi==L
        f(i,1)=po;
    end
 end
p=A2\f;%-------------------------迭代步长

%-------------------------------------------------------------计算误差
for i=1:n_elem
    xi=elements(i,1);
    yi=elements(i,2);
    if (scrnum(i,1)==0)&&i~=center
        u_p(i,1)=-miu/(4*pi*ka)*(ne*log((xi-0)^2+(yi-0)^2)+po*log((xi-L)^2+(yi-L)^2));
    end
    u_p(center,1)=po;
end
ERROR=p-u_p;
i=1;
for j=1:n_elem
    if scrnum(j,1)==0
        error(i,1)=ERROR(j,1);
        i=i+1;
    end
end
ee=max(abs(error));
%--------------------------------------------------------------------------pressure画图
i=1;
for j=1:n_elem
    if scrnum(j,1)==0
        n_elements(i,1)=elements(j,1);
        n_elements(i,2)=elements(j,2);
        n_P(i,1)=p(j,1);
        n_u_p(i,1)=u_p(j,1);
        i=i+1;
    end
end
X=reshape(n_elements(:,1),sqrt(size(n_elements,1)),sqrt(size(n_elements,1)));
Y=X';
P=reshape(n_P,sqrt(size(n_elements,1)),sqrt(size(n_elements,1)));
U_p=reshape(n_u_p,sqrt(size(n_elements,1)),sqrt(size(n_elements,1)));
%----------------------------------------------------------------------------误差：L_2

L2s=0;
L2ss=0;
for i=1:size(error)
    L2s=L2s+(error(i))^2;
    L2ss=L2ss+n_u_p(i)^2;
end
L2=(L2s/L2ss)^(1/2);

fprintf('L2=%d',L2);

save('X.txt','X','-ascii')
save('Y.txt','Y','-ascii')
save('U_p_state.txt','P','-ascii')

% 
% % %%
figure(1)
subplot(1,2,1)
surf(X,Y,P)
hold on
% contour(X,Y,P)
% title('解析解')
colorbar('eastoutside');
% caxis([m_inf m_sup]);
subplot(1,2,2)
surf(X,Y,U_p)
hold on
% contour(X,Y,U_p)
% title('真解')
colorbar('eastoutside');
camp=colormap(othercolor('BuDRd_12'));
% camp=camp(end:-1:1,:);
colormap(camp)

% 
