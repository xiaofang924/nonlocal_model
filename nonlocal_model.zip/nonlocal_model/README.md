# nonlocal_model
code for article
This code is the code in the author's article, and the order is consistent with the example of the article.

author: xiaofang wang
