tic
clc
clear

pi=3.1415926;
epsilon=1;
N=20;
fd_s_d=1;
Delta=1/N;
Horizon=3*Delta;
nxH=3;
nyH=3;
x_len=nxH*Horizon;
y_len=nyH*Horizon;
xl_int=fix(x_len/Delta);
yl_int=fix(y_len/Delta);

n_elem =(N+yl_int*2+1)*(N+xl_int*2+1);

A1=zeros(n_elem);
A2=zeros(n_elem);
A3=zeros(n_elem);

V=1;
elements=zeros(n_elem,2);
for i=0:(N+yl_int*2)
    for j=0:(N+xl_int*2)
        elements(V,2)=i/N-yl_int/N;
        elements(V,1)=j/N-xl_int/N;
        V=V+1;
    end
end

%区分点在内部0/外部1
    for i=1:n_elem
     xi=elements(i,1);
     yi=elements(i,2);
     if (xi<1e-10||xi>1-1e-10||yi<=1e-10||yi>1-1e-10)
         scrnum(i,1)=1;
     end
    end
    
%扩散系数

 a=@(x,y) 100;
 b=0;
 c=0;
 d=@(x,y) 1;


 for i=1:n_elem
    
    xi=elements(i,1);
    yi=elements(i,2);

    %求M
    A_x=[a(xi,yi),0;0,d(xi,yi)];  
    [V_x,D_x]=eig(A_x);
    M_x_inverse=V_x*sqrt(inv(D_x))*V_x';

    if scrnum(i,1)==0

        ennum=0;
        num=0;
        enennum=0;
        kernel_1=zeros(1300,1);
        kernel_2=zeros(1300,1);
        kernel_3=zeros(1300,1);
        Aeq_1=zeros(5,1300);
        Aeq_2=zeros(5,1300);
        Aeq_3=zeros(5,1300);
        NAeq_1=zeros(1300,1);
        NAeq_2=zeros(1300,1);
        NAeq_3=zeros(1300,1);
        elements1=zeros(1300,2);

      for j=1:n_elem
          

           xj=elements(j,1);
           yj=elements(j,2);

           A_y=[a(xj,yj),0;0,d(xj,yj)];
           [V_y,D_y]=eig(A_y);
           M_y_inverse=V_y*sqrt(inv(D_y))*V_y';
            
           
           %截断条件B
        
            if((i~=j)&&((xj-xi).^2*M_x_inverse(1,1).^2+(yj-yi).^2*M_x_inverse(2,2).^2<=Horizon.^2)&&((xj-xi).^2*M_y_inverse(1,1).^2+(yj-yi).^2*M_y_inverse(2,2).^2>Horizon.^2))

                ennum=ennum+1;

                kernel_1(ennum,1)=(1/(pi*Horizon.^2)).*((xj-xi).^2*M_x_inverse(1,1).^2+(yj-yi).^2*M_x_inverse(2,2).^2).^(-3/2).*det(M_x_inverse);
                    
                elements1(ennum,1)=xj;
                elements1(ennum,2)=yj;


                Aeq_1(1,ennum)=(xj-xi).*kernel_1(ennum,1);
                Aeq_1(2,ennum)=(yj-yi).*kernel_1(ennum,1);
                Aeq_1(3,ennum)=(xj*yj-xi*yi).*kernel_1(ennum,1);
                Aeq_1(4,ennum)=(xj.^2-xi.^2).*kernel_1(ennum,1);
                Aeq_1(5,ennum)=(yj.^2-yi.^2).*kernel_1(ennum,1);
                   
                NAeq_1(ennum,1)=j;
                   
           end
      end

      for j=1:n_elem
          

           xj=elements(j,1);
           yj=elements(j,2);

           A_y=[a(xj,yj),0;0,d(xj,yj)];
           [V_y,D_y]=eig(A_y);
           M_y_inverse=V_y*sqrt(inv(D_y))*V_y';
            
           
           %截断条件B
        
            if((i~=j)&&((xj-xi).^2*M_x_inverse(1,1).^2+(yj-yi).^2*M_x_inverse(2,2).^2>Horizon.^2)&&((xj-xi).^2*M_y_inverse(1,1).^2+(yj-yi).^2*M_y_inverse(2,2).^2<=Horizon.^2))

                num=num+1;

                kernel_2(num,1)=+(1/(pi*Horizon.^2)).*((xj-xi).^2*M_y_inverse(1,1).^2+(yj-yi).^2*M_y_inverse(2,2).^2).^(-3/2).*det(M_y_inverse);

                elements2(num,1)=xj;
                elements2(num,2)=yj;

                               
                Aeq_2(1,num)=(xj-xi).*kernel_2(num,1);
                Aeq_2(2,num)=(yj-yi).*kernel_2(num,1);
                Aeq_2(3,num)=(xj*yj-xi*yi).*kernel_2(num,1);
                Aeq_2(4,num)=(xj.^2-xi.^2).*kernel_2(num,1);
                Aeq_2(5,num)=(yj.^2-yi.^2).*kernel_2(num,1);
                   
                NAeq_2(num,1)=j;
                   
           end
      end

      for j=1:n_elem
          

           xj=elements(j,1);
           yj=elements(j,2);

           A_y=[a(xj,yj),0;0,d(xj,yj)];
           [V_y,D_y]=eig(A_y);
           M_y_inverse=V_y*sqrt(inv(D_y))*V_y';
            
           
           %截断条件B
        
            if((i~=j)&&((xj-xi).^2*M_x_inverse(1,1).^2+(yj-yi).^2*M_x_inverse(2,2).^2<=Horizon.^2)&&((xj-xi).^2*M_y_inverse(1,1).^2+(yj-yi).^2*M_y_inverse(2,2).^2<=Horizon.^2))

                enennum=enennum+1;

                kernel_3(enennum,1)=(1/(pi*Horizon.^2)).*((xj-xi).^2*M_x_inverse(1,1).^2+(yj-yi).^2*M_x_inverse(2,2).^2).^(-3/2).*det(M_x_inverse)+(1/(pi*Horizon.^2)).*((xj-xi).^2*M_y_inverse(1,1).^2+(yj-yi).^2*M_y_inverse(2,2).^2).^(-3/2).*det(M_y_inverse);

                elements3(enennum,1)=xj;
                elements3(enennum,2)=yj;

                               
                Aeq_3(1,enennum)=(xj-xi).*kernel_3(enennum,1);
                Aeq_3(2,enennum)=(yj-yi).*kernel_3(enennum,1);
                Aeq_3(3,enennum)=(xj*yj-xi*yi).*kernel_3(enennum,1);
                Aeq_3(4,enennum)=(xj.^2-xi.^2).*kernel_3(enennum,1);
                Aeq_3(5,enennum)=(yj.^2-yi.^2).*kernel_3(enennum,1);
                   
                NAeq_3(enennum,1)=j;
                   
           end
      end

      kk=1;
      for k=ennum+1:ennum+num
          Aeq_1(1:5,k)=Aeq_2(1:5,kk);
          kernel_1(k,1)=kernel_2(kk,1);
          NAeq_1(k,1)=NAeq_2(kk,1);
         % elements1(k,1:2)=elements2(kk,1:2);
          kk=kk+1;
      end

      zz=1;
      for z=ennum+num+1:ennum+num+enennum
          Aeq_1(1:5,z)=Aeq_3(1:5,zz);
          kernel_1(z,1)=kernel_3(zz,1);
          NAeq_1(z,1)=NAeq_3(zz,1);
         % elements1(z,1:2)=elements3(zz,1:2);
          zz=zz+1;
      end

        beq=zeros(5,1);
        
        beq(1,1)=4*xi;
        beq(2,1)=4*yi;
        beq(3,1)=8*xi*yi;
        beq(4,1)=2+12*xi.^2+2*yi^2;
        beq(5,1)=2+12*yi.^2+2*xi^2;
        % beq(1,1)=0;
        % beq(2,1)=0;
        % beq(3,1)=0;
        % beq(4,1)=2*a(xi,yi);
        % beq(5,1)=2*d(xi,yi);


        S=Aeq_1*Aeq_1';
        x=Aeq_1'*inv(S)*beq;

        for k=1:ennum
              A1(i,NAeq_1(k,1))=x(k).*kernel_1(k,1);
        end

        for k=ennum+1:num+ennum
              A2(i,NAeq_1(k,1))=x(k).*kernel_1(k,1);
        end

        for k=ennum+num+1:num+ennum+enennum
              A3(i,NAeq_1(k,1))=x(k).*kernel_1(k,1);
        end

    end
 end

 A=A1+A2+A3;

for i=1:n_elem
    A(i,i)=0;
end

%-----------对角线元素----------%
for i=1:n_elem
        
        if scrnum(i,1)==0
            A(i,i)=-sum(A(i,:));
        else
            A(i,i)=1;
        end
end
  

%------------右端项-----------%
F=zeros(n_elem,1) ;
for i=1:n_elem
    xi=elements(i,1);
    yi=elements(i,2);
    if scrnum(i,1)==0
          F(i)=a(xi,yi)*(2*cos(xi*xi+yi*yi)-4*xi*xi*sin(xi*xi+yi*yi))+d(xi,yi)*(2*cos(xi*xi+yi*yi)-4*yi*yi*sin(xi*xi+yi*yi))+4*xi*(2*xi*cos(xi*xi+yi*yi))+4*yi*(2*yi*cos(xi*xi+yi*yi));
         % F(i)=2*a(xi,yi)*cos(xi*xi+yi*yi)-4*a(xi,yi)*xi*xi*sin(xi*xi+yi*yi)+2*d(xi,yi)*sin(xi*xi+yi*yi)+4*d(xi,yi)*yi*yi*cos(xi*xi+yi*yi);
   
    else        

         F(i)=sin(xi*xi+yi*yi);
    end
end
 
 
%------------求解-------------%

UU=gmres(A,F,[],[],5000);
UE=zeros(n_elem,1); 



for i=1:n_elem
                xi=elements(i,1);
                yi=elements(i,2);
                UE(i)=sin(xi*xi+yi*yi);
end
ERROR=UU-UE;
ee=max(abs(ERROR));


%-----------L2误差-----------%
er=0;
e=0;
for i=1:n_elem
    xi=elements(i,1);
    yi=elements(i,2);
    

    e=(sin(xi*xi+yi*yi)-UU(i)).^2.*Delta.^2;
    er=er+e;
end
er=sqrt(er);
toc
fprintf('er=%d',er);
% a=cond(A);
% save('A80.txt','A80','-ascii')