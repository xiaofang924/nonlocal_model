clc
clear

pi=3.1415926;
epsilon=1;
N=40;
fd_s_d=1;
Delta=1/N;
Horizon=3*Delta;
nxH=3;
nyH=3;
x_len=nxH*Horizon;
y_len=nyH*Horizon;
xl_int=fix(x_len/Delta);
yl_int=fix(y_len/Delta);

n_elem =(N+yl_int*2+1)*(N+xl_int*2+1);

A1=zeros(n_elem);
A2=zeros(n_elem);
A3=zeros(n_elem);

V=1;
elements=zeros(n_elem,2);
for i=0:(N+yl_int*2)
    for j=0:(N+xl_int*2)
        elements(V,2)=i/N-yl_int/N;
        elements(V,1)=j/N-xl_int/N;
        V=V+1;
    end
end

   %区分点在内部0/外部1
    for i=1:n_elem
     xi=elements(i,1);
     yi=elements(i,2);
     if (xi<1e-10||xi>1-1e-10||yi<=1e-10||yi>1-1e-10)
         scrnum(i,1)=1;
     end
    end
    
%扩散系数
a1=@(x,y) 1+2*x*x+y*y;
b1=0;
c1=0;
d1=@(x,y) 1+x*x+2*y*y;


a=@(x,y) a1(x,y)*cos(5*pi/12)*cos(5*pi/12)+d1(x,y)*cos(5*pi/12)*sin(5*pi/12);
b=@(x,y) -a1(x,y)*sin(5*pi/12)*cos(5*pi/12)+d1(x,y)*sin(5*pi/12)*cos(5*pi/12);
c=@(x,y) -a1(x,y)*sin(5*pi/12)*cos(5*pi/12)+d1(x,y)*sin(5*pi/12)*cos(5*pi/12);
d=@(x,y) -a1(x,y)*cos(5*pi/12)*cos(5*pi/12)+d1(x,y)*cos(5*pi/12)*sin(5*pi/12);


 for i=1:n_elem
    
    xi=elements(i,1);
    yi=elements(i,2);

    %求M
    A_x=[a(xi,yi),0;0,d(xi,yi)];  
    [V_x,D_x]=eig(A_x);
    M_x_inverse=V_x*sqrt(inv(D_x))*V_x';

    if scrnum(i,1)==0

        ennum=0;
        num=0;
        enennum=0;
        kernel_1=zeros(1300,1);
        kernel_2=zeros(1300,1);
        kernel_3=zeros(1300,1);
        Aeq_1=zeros(5,1300);
        Aeq_2=zeros(5,1300);
        Aeq_3=zeros(5,1300);
        NAeq_1=zeros(1300,1);
        NAeq_2=zeros(1300,1);
        NAeq_3=zeros(1300,1);
        elements1=zeros(1300,2);

      for j=1:n_elem
          

           xj=elements(j,1);
           yj=elements(j,2);

           A_y=[a(xj,yj),0;0,d(xj,yj)];
           [V_y,D_y]=eig(A_y);
           M_y_inverse=V_y*sqrt(inv(D_y))*V_y';
            
           
           %截断条件B
        
            if((i~=j)&&(((xj-xi)*M_x_inverse(1,1)+(yj-yi)*M_x_inverse(1,2)).^2+((yj-yi)*M_x_inverse(2,2)+(xj-xi)*M_x_inverse(2,1)).^2<=Horizon.^2)&&(((xj-xi)*M_y_inverse(1,1)+(yj-yi)*M_y_inverse(1,2)).^2+((yj-yi)*M_y_inverse(2,2)+(xj-xi)*M_y_inverse(2,1)).^2>Horizon.^2))

                ennum=ennum+1;

                kernel_1(ennum,1)=(1/(pi*Horizon.^2)).*(((xj-xi)*M_x_inverse(1,1)+(yj-yi)*M_x_inverse(1,2)).^2+((yj-yi)*M_x_inverse(2,2)+(xj-xi)*M_x_inverse(2,1)).^2).^(-3/2).*det(M_x_inverse);
                    
                elements1(ennum,1)=xj;
                elements1(ennum,2)=yj;

                Aeq_1(1,ennum)=(xj-xi).*kernel_1(ennum,1);
                Aeq_1(2,ennum)=(yj-yi).*kernel_1(ennum,1);
                Aeq_1(3,ennum)=(xj*yj-xi*yi).*kernel_1(ennum,1);
                Aeq_1(4,ennum)=(xj.^2-xi.^2).*kernel_1(ennum,1);
                Aeq_1(5,ennum)=(yj.^2-yi.^2).*kernel_1(ennum,1);
                   
                NAeq_1(ennum,1)=j;
                   
           end
      end

      for j=1:n_elem
          

           xj=elements(j,1);
           yj=elements(j,2);

           A_y=[a(xj,yj),0;0,d(xj,yj)];
           [V_y,D_y]=eig(A_y);
           M_y_inverse=V_y*sqrt(inv(D_y))*V_y';
            
           
           %截断条件B
        
            if((i~=j)&&(((xj-xi)*M_x_inverse(1,1)+(yj-yi)*M_x_inverse(1,2)).^2+((yj-yi)*M_x_inverse(2,2)+(xj-xi)*M_x_inverse(2,1)).^2>Horizon.^2)&&(((xj-xi)*M_y_inverse(1,1)+(yj-yi)*M_y_inverse(1,2)).^2+((yj-yi)*M_y_inverse(2,2)+(xj-xi)*M_y_inverse(2,1)).^2<=Horizon.^2))

                num=num+1;

                kernel_2(num,1)=(1/(pi*Horizon.^2)).*(((xj-xi)*M_y_inverse(1,1)+(yj-yi)*M_y_inverse(1,2)).^2+((yj-yi)*M_y_inverse(2,2)+(xj-xi)*M_y_inverse(2,1)).^2).^(-3/2).*det(M_x_inverse);

                elements2(num,1)=xj;
                elements2(num,2)=yj;
                               
                Aeq_2(1,num)=(xj-xi).*kernel_2(num,1);
                Aeq_2(2,num)=(yj-yi).*kernel_2(num,1);
                Aeq_2(3,num)=(xj*yj-xi*yi).*kernel_2(num,1);
                Aeq_2(4,num)=(xj.^2-xi.^2).*kernel_2(num,1);
                Aeq_2(5,num)=(yj.^2-yi.^2).*kernel_2(num,1);
                   
                NAeq_2(num,1)=j;
                   
           end
      end

      for j=1:n_elem
          

           xj=elements(j,1);
           yj=elements(j,2);

           A_y=[a(xj,yj),0;0,d(xj,yj)];
           [V_y,D_y]=eig(A_y);
           M_y_inverse=V_y*sqrt(inv(D_y))*V_y';
            
           
           %截断条件B
        
            if((i~=j)&&(((xj-xi)*M_x_inverse(1,1)+(yj-yi)*M_x_inverse(1,2)).^2+((yj-yi)*M_x_inverse(2,2)+(xj-xi)*M_x_inverse(2,1)).^2<=Horizon.^2)&&(((xj-xi)*M_y_inverse(1,1)+(yj-yi)*M_y_inverse(1,2)).^2+((yj-yi)*M_y_inverse(2,2)+(xj-xi)*M_y_inverse(2,1)).^2<=Horizon.^2))

                enennum=enennum+1;

                kernel_3(enennum,1)=(1/(pi*Horizon.^2)).*(((xj-xi)*M_x_inverse(1,1)+(yj-yi)*M_x_inverse(1,2)).^2+((yj-yi)*M_x_inverse(2,2)+(xj-xi)*M_x_inverse(2,1)).^2).^(-3/2).*det(M_x_inverse)+(1/(pi*Horizon.^2)).*(((xj-xi)*M_y_inverse(1,1)+(yj-yi)*M_y_inverse(1,2)).^2+((yj-yi)*M_y_inverse(2,2)+(xj-xi)*M_y_inverse(2,1)).^2).^(-3/2).*det(M_x_inverse);


                elements3(enennum,1)=xj;
                elements3(enennum,2)=yj;
                               
                Aeq_3(1,enennum)=(xj-xi).*kernel_3(enennum,1);
                Aeq_3(2,enennum)=(yj-yi).*kernel_3(enennum,1);
                Aeq_3(3,enennum)=(xj*yj-xi*yi).*kernel_3(enennum,1);
                Aeq_3(4,enennum)=(xj.^2-xi.^2).*kernel_3(enennum,1);
                Aeq_3(5,enennum)=(yj.^2-yi.^2).*kernel_3(enennum,1);
                   
                NAeq_3(enennum,1)=j;
                   
           end
      end

      kk=1;
      for k=ennum+1:ennum+num
          Aeq_1(1:5,k)=Aeq_2(1:5,kk);
          kernel_1(k,1)=kernel_2(kk,1);
          NAeq_1(k,1)=NAeq_2(kk,1);
         % elements1(k,1:2)=elements2(kk,1:2);
          kk=kk+1;
      end

      zz=1;
      for z=ennum+num+1:ennum+num+enennum
          Aeq_1(1:5,z)=Aeq_3(1:5,zz);
          kernel_1(z,1)=kernel_3(zz,1);
          NAeq_1(z,1)=NAeq_3(zz,1);
         % elements1(z,1:2)=elements3(zz,1:2);
          zz=zz+1;
      end

        beq=zeros(5,1);
        
       beq(1,1)=4*xi*cos(5*pi/12)*cos(5*pi/12)+2*xi*sin(5*pi/12)*sin(5*pi/12)+2*yi*cos(5*pi/12)*sin(5*pi/12);
       beq(2,1)=4*yi*cos(5*pi/12)*cos(5*pi/12)+2*yi*sin(5*pi/12)*sin(5*pi/12)-2*xi*cos(5*pi/12)*sin(5*pi/12);
       beq(3,1)=8*xi*yi*cos(5*pi/12)*cos(5*pi/12)+4*xi*yi*sin(5*pi/12)*sin(5*pi/12)+(-2*a1(xi,yi)+2*d1(xi,yi)-2*xi.^2+2*yi.^2)*cos(5*pi/12)*sin(5*pi/12);
       beq(4,1)=(2*a1(xi,yi)+8*xi.^2)*cos(5*pi/12)*cos(5*pi/12)+(2*d1(xi,yi)+4*xi.^2)*sin(5*pi/12)*sin(5*pi/12)+4*xi*yi*cos(5*pi/12)*sin(5*pi/12);
       beq(5,1)=(2*d1(xi,yi)+8*yi.^2)*cos(5*pi/12)*cos(5*pi/12)+(2*a1(xi,yi)+4*yi.^2)*sin(5*pi/12)*sin(5*pi/12)-4*xi*yi*cos(5*pi/12)*sin(5*pi/12);


        S=Aeq_1*Aeq_1';
        x1=Aeq_1'*inv(S)*beq;

        for k=1:ennum
              A1(i,NAeq_1(k,1))=x1(k).*kernel_1(k,1);
        end

        for k=ennum+1:num+ennum
              A2(i,NAeq_1(k,1))=x1(k).*kernel_1(k,1);
        end

        for k=ennum+num+1:num+ennum+enennum
              A3(i,NAeq_1(k,1))=x1(k).*kernel_1(k,1);
        end

    end
 end

 A=A1+A2+A3;

for i=1:n_elem
    A(i,i)=0;
end

%-----------对角线元素----------%
for i=1:n_elem
        
        if scrnum(i,1)==0
            A(i,i)=-sum(A(i,:));
        else
            A(i,i)=1;
        end
end
  

%------------右端项-----------%
F=zeros(n_elem,1) ;
 for i=1:n_elem
                xi=elements(i,1);
                yi=elements(i,2);

            if scrnum(i,1)==1 
                if xi<=0||yi<=0
                    F(i)=1;
                end
            
            else 
                F(i)=0; 
            end
 end
 
 %------------求解-------------%
UU=gmres(A,F,[],[],5000);
UE=zeros(n_elem,1); 

max1=max(UU);
min1=min(UU);


for i=1:n_elem
    x(i)=elements(i,1);
    y(i)=elements(i,2);
    z(i)=UU(i);
end
scatter3(x,y,z)



figure(1)
p=reshape(x,59,59);
q=reshape(y,59,59);
r=reshape(z,59,59);
surf(p,q,r)
 
 xlim([-0.075 1.075])
 ylim([-0.075 1.075])
 zlim([0 1])
colorbar
clim([0,1]);
view(80.7,35.19)