function [triangulation,elements]=triangular_mesh_2(n_elem,N,xl_int,yl_int)

%2D随机网
V=1;
elements=zeros(n_elem,2);
for i=0:(N+yl_int*2)
    for j=0:(N+xl_int*2)
        elements(V,2)=(i+unifrnd(-0.2,0.2,1))/N-yl_int/N;
        elements(V,1)=(j+unifrnd(-0.2,0.2,1))/N-xl_int/N;
        if V>1&&V<xl_int*2+N+1
            elements(V,2)=-yl_int/N;
        elseif V>((xl_int*2+N+1)*(yl_int*2+N)+1)&&V<n_elem
            elements(V,2)=1+yl_int/N;
        elseif rem(V,xl_int*2+N+1)==0&&V~=xl_int*2+N+1&&V~=n_elem
            elements(V,1)=1+xl_int/N;
        elseif rem(V-1,xl_int*2+N+1)==0&&V~=1&&V~=((xl_int*2+N+1)*(yl_int*2+N)+1)
            elements(V,1)=-xl_int/N;
        elseif V==1
            elements(V,1)=-xl_int/N;
            elements(V,2)=-yl_int/N;
        elseif V==xl_int*2+N+1
            elements(V,1)=1+xl_int/N;
            elements(V,2)=-yl_int/N;
        elseif V==n_elem
            elements(V,1)=1+xl_int/N;
            elements(V,2)=1+yl_int/N;
        elseif V==((xl_int*2+N+1)*(yl_int*2+N)+1)
            elements(V,1)=-xl_int/N;
            elements(V,2)=1+yl_int/N;
        end
        V=V+1;
    end
end


%形成非均匀三角网
triangulation = delaunay(elements(:,1), elements(:,2));

% %非均匀三角网作图
% triplot(triangulation, elements(:,1),elements(:,2));
% axis equal;

end